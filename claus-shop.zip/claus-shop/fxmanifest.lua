fx_version 'cerulean'
game 'gta5'

author 'Claus'
description 'ox_inventory shop script for qb and ox target'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_scripts {
    'client/*.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*.lua',
}
